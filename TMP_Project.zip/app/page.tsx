'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/context/auth-context';
import { FullScreenLoader } from '@/components/ui/LoadingAnimation';

// Root hanya bertugas mengarahkan ke route yang sesuai dengan status sesi.
export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    router.replace(user ? '/dashboard' : '/login');
  }, [user, loading, router]);

  return <FullScreenLoader />;
}
